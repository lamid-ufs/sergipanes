export { default as TeamNameLine } from "./PTeamNameLine";
export { default as CurrentWord } from "./PCurrentWord";
export { default as MeaningOptions } from "./PMeaningOptions";
export { default as NonDesktopTimer } from "./PNonDesktopTimer";
export { default as ButtonLine } from "./PButtonsLine";