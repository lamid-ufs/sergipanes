export { default as Thanks } from "./PThanks";
export { default as Scores } from "./PScores";
export { default as Buttons } from "./PButtons";